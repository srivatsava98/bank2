package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class BankingDAOServicesImpl implements BankingDAOServices {
	private static HashMap<Integer, Customer> customerList = new HashMap<>();
	private static int CUSTOMER_ID_COUNTER=111;
	private static int ACCOUNT_ID_COUNTER=1234567;
	private static int TRANSACTION_ID_COUNTER=4567;
	static Random rand = new Random();
	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(CUSTOMER_ID_COUNTER);
		customerList.put(CUSTOMER_ID_COUNTER++, customer);
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		getCustomer(customerId).getAccountList().put(ACCOUNT_ID_COUNTER++, account);
		return account.getAccountNo();
	}
	
	@Override
	public boolean updateAccount(int customerId, Account account) {
		getCustomer(customerId).getAccountList().put(ACCOUNT_ID_COUNTER, account);
		return true;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		getCustomer(customerId).getAccountList().get(account.getAccountNo()).setPinNumber(rand.nextInt(10000));	
		return account.getPinNumber();
		}
	
	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		getAccount(customerId, accountNo).getTransactionList().put(TRANSACTION_ID_COUNTER++, transaction);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		customerList.remove(customerId);
		return true;
	}	

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		customerList.get(customerId).getAccountList().remove(accountNo);
		return true;
	}

	@Override
	public Customer getCustomer(int customerId) {
		return customerList.get(customerId);
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		return customerList.get(customerId).getAccountList().get(accountNo);
	}

	@Override
	public List<Customer> getCustomers() {
		return new ArrayList<>(customerList.values());
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		return new ArrayList<>(customerList.get(customerId).getAccountList().values());
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		return new ArrayList<>(getAccount(customerId, accountNo).getTransactionList().values());
	}
}